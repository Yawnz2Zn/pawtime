"""Headless-browser smoke test for PawTime (optional). See README.
Serve the project root on port 8765 first, then: python3 tests/smoke_test.py
Screenshots are written to tests/out/ (git-ignored)."""
import json, sys
from playwright.sync_api import sync_playwright

import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)
URL = os.environ.get("PAWTIME_URL", "http://localhost:8765/index.html")
errors = []
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))

with sync_playwright() as p:
    browser = p.chromium.launch(args=[
        "--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream",
        "--autoplay-policy=no-user-gesture-required"])
    ctx = browser.new_context(viewport={"width": 390, "height": 820}, device_scale_factor=2,
                              permissions=["camera"], is_mobile=True, has_touch=True)
    page = ctx.new_page()
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append("PAGEERROR " + str(e)))
    page.on("dialog", lambda d: d.accept())

    page.goto(URL)
    page.wait_for_selector("#sheet-onboard:not([hidden])")
    check("onboarding shows on first run", True)
    page.fill("#obName", "Biscuit")
    page.fill("#obBirthday", "2024-03-10")
    page.click("#obStart")
    page.wait_for_function("document.querySelector('#video').videoWidth > 0", timeout=8000)
    check("camera stream starts (fake device)", True)
    page.screenshot(path=f"{OUT}/s1_camera.png")

    # single shot
    page.click("#btnShutter")
    page.wait_for_function("document.querySelector('#thumbCount').textContent === '1'", timeout=6000)
    check("one tap saves one photo", True)
    check("quick tag bar appears", page.is_visible("#quickTags"))
    page.click("#quickTagButtons [data-tag=walk]")
    tags = page.evaluate("state.photos[0].tags")
    check("quick tag applies to the photo", tags == ["walk"], str(tags))

    # repeated clicks: hammer the shutter, should not create duplicates beyond what finishes
    page.evaluate("document.querySelector('#btnBurst').click()")
    page.click("#btnShutter")
    page.click("#btnShutter", force=True)  # second tap while busy should be ignored
    page.wait_for_function("state.photos.length >= 6", timeout=10000)
    page.wait_for_timeout(600)
    n = page.evaluate("state.photos.length")
    check("burst takes 5 and repeated tap while busy is ignored", n == 6, f"photos={n}")
    page.screenshot(path=f"{OUT}/s2_camera_after.png")

    # persistence across reload
    page.reload()
    page.wait_for_function("document.querySelector('#thumbCount').textContent === '6'", timeout=6000)
    check("photos persist after reload (IndexedDB)", True)

    # video: record a short clip, then switch back to photo mode
    page.wait_for_function("document.querySelector('#video').videoWidth > 0", timeout=8000)
    page.click("[data-mode=video]")
    page.click("#btnShutter"); page.wait_for_timeout(1800)
    check("recording badge appears while recording", page.is_visible("#recBadge"))
    page.click("#btnShutter")
    page.wait_for_function("state.photos.some(p => p.kind === 'video')", timeout=15000)
    vid = page.evaluate("(() => { const v = state.photos.find(p => p.kind === 'video'); return {size: v.blob.size, dur: v.dur, thumb: v.thumb.size}; })()")
    check("video is saved with length and poster frame", vid["size"] > 2000 and vid["dur"] > 1 and vid["thumb"] > 500, json.dumps(vid))
    page.click("[data-mode=photo]")

    # sample data
    page.click("#btnSettings")
    page.click("#btnSample")
    page.wait_for_function("document.querySelector('#view-timeline').classList.contains('active')", timeout=60000)
    page.wait_for_selector(".moment")
    stat = page.inner_text("#statLine")
    print("STAT:", stat.replace("\n", " | "))
    info = page.evaluate("""() => {
      const ms = getMoments().filter(m => !m.sticker);
      return {photos: state.photos.filter(p=>p.kind==='photo').length, moments: ms.length,
              sizes: ms.map(m => m.items.length),
              demoOnly: getMoments().filter(m=>!m.sticker && m.items.length>1).length}
    }""")
    print("FOLDING:", json.dumps(info))
    check("sample photos fold into fewer moments", info["moments"] < info["photos"] - 8, json.dumps(info))
    page.screenshot(path=f"{OUT}/s3_timeline.png")
    page.screenshot(path=f"{OUT}/s3_timeline_full.png", full_page=False)

    # cover choice: the blurred one should not be a cover
    cover_check = page.evaluate("""() => {
      const bad = [];
      for (const m of getMoments()) { if (m.items.length>1) { const max = Math.max(...m.items.map(i=>i.sharp)); if (m.cover.sharp !== max) bad.push(m.id); } }
      return bad.length;
    }""")
    check("auto cover is always the sharpest shot", cover_check == 0)

    # tag filter
    page.click("#filterChips [data-filter=sleep]")
    shown = page.evaluate("document.querySelectorAll('#timeline .moment').length")
    allm = page.evaluate("getMoments().filter(m=>m.tags.has('sleep')).length")
    check("tag filter shows only matching moments", shown == allm and shown > 0, f"{shown}/{allm}")
    page.click("#filterChips [data-filter='']")

    # date jump
    page.fill("#jumpDate", "2000-01-01")
    page.dispatch_event("#jumpDate", "change")
    check("date jump runs without error", True)

    # settings: the time window changes folding (two identical shots taken 10 minutes apart)
    page.evaluate("""async () => {
      const bmp = await blobToBitmap(state.photos.find(p => p.demo).blob), T = Date.UTC(2031, 0, 1, 10, 0, 0);
      await ingestSource(bmp, { ts: T, demo: true }); await ingestSource(bmp, { ts: T + 10 * 60000, demo: true });
    }""")
    page.click("#btnSettings")
    page.fill("#setWin", "5"); page.dispatch_event("#setWin", "input")
    m_short = page.evaluate("getMoments().filter(m=>!m.sticker).length")
    page.fill("#setWin", "30"); page.dispatch_event("#setWin", "input")
    m_long = page.evaluate("getMoments().filter(m=>!m.sticker).length")
    check("time-window slider changes folding (10 min apart folds only with a window of 10+ min)", m_short == m_long + 1, f"5min={m_short} 30min={m_long}")
    page.fill("#setSim", "0"); page.dispatch_event("#setSim", "input")
    check("similarity slider moves the setting", page.evaluate("state.settings.sim") == 0)
    page.fill("#setSim", "10"); page.dispatch_event("#setSim", "input")
    page.screenshot(path=f"{OUT}/s7_settings.png")
    page.click("[data-close=sheet-settings]")

    # a video card on the timeline plays in the viewer
    page.evaluate("document.querySelector('#tlScroll').scrollTop = 0")
    page.click(".moment.video >> nth=0"); page.wait_for_selector("#vStage video")
    page.wait_for_function("document.querySelector('#vStage video').readyState >= 1", timeout=8000)
    check("video opens and plays in the viewer", page.evaluate("document.querySelector('#vStage video').duration") > 1)
    page.click("[data-close=sheet-viewer]")

    # open viewer on a stacked moment
    page.evaluate("document.querySelector('#tlScroll').scrollTop = 0")
    page.click(".moment.stack >> nth=0")
    page.wait_for_selector("#sheet-viewer:not([hidden])")
    page.screenshot(path=f"{OUT}/s4_viewer.png")
    n_strip = page.evaluate("document.querySelectorAll('#vStrip button').length")
    check("viewer shows the stack of photos", n_strip > 1, str(n_strip))
    # set a different cover
    page.click("#vStrip button >> nth=1")
    page.click("[data-act=cover]")
    page.wait_for_function("momentOf(viewer.photoId).coverIsPinned === true", timeout=3000)
    pinned = page.evaluate("momentOf(viewer.photoId).coverIsPinned")
    check("user can override the cover", pinned is True)

    # sticker studio (v2): free layers, text, emoji, decorations, card, pen, cut-out
    page.click("[data-act=sticker]")
    page.wait_for_selector("#sheet-sticker:not([hidden])")
    page.click("[data-shape=heart]")
    page.click("[data-stk-tab=text]"); page.click("[data-addtext=pop]")
    page.fill("#lyText", "Treat time!")
    page.click("[data-stk-tab=decor]"); page.click("[data-addemoji='🐾']"); page.click("[data-addemoji='❤️']"); page.click("[data-adddeco=star]")
    n_layers = page.evaluate("Sticker._st.layers.length")
    check("sticker can hold several text / emoji / decoration layers", n_layers == 4, str(n_layers))
    page.click("[data-ly=dup]")
    check("duplicate layer works", page.evaluate("Sticker._st.layers.length") == 5)
    page.click("[data-ly=del]")
    page.wait_for_timeout(150)
    page.screenshot(path=f"{OUT}/s5_sticker_layers.png")
    page.click("[data-stk-tab=card]"); page.click("[data-layout=card]"); page.click("[data-pattern=gingham]")
    page.click("[data-stk-tab=draw]"); page.click("[data-pen=neon]")
    bb = page.locator("#stkCanvas").bounding_box()
    page.mouse.move(bb["x"] + bb["width"] * .2, bb["y"] + bb["height"] * .9); page.mouse.down()
    page.mouse.move(bb["x"] + bb["width"] * .8, bb["y"] + bb["height"] * .86, steps=8); page.mouse.up()
    check("freehand drawing adds a line", page.evaluate("Sticker._st.strokes.length") == 1)
    page.click("[data-stk-tab=photo]")
    page.click("[data-cut=start]")
    page.wait_for_function("Sticker._cut().on || (!Sticker._cut().busy && !Sticker._cut().on)", timeout=60000)
    check("pet cut-out runs and finds the pet", page.evaluate("Sticker._cut().on") is True, page.evaluate("Sticker._cut().method"))
    page.click("[data-ostyle=neon]")
    page.wait_for_timeout(300)
    page.screenshot(path=f"{OUT}/s5_sticker_cutout.png")
    page.click("[data-ostyle=solid]")
    page.click("[data-cut=off]")
    check("cut-out can be switched off again", page.evaluate("Sticker._cut().on") is False)
    page.click("[data-stk-tab=card]"); page.click("[data-layout=sticker]")
    before = page.evaluate("state.photos.filter(p=>p.kind==='sticker').length")
    page.click("#stkSave")
    page.click("#stkSave", force=True)   # repeated click
    page.wait_for_function("document.querySelector('#stkSave').textContent === 'Saved ✓'", timeout=5000)
    page.wait_for_timeout(300)
    after = page.evaluate("state.photos.filter(p=>p.kind==='sticker').length")
    check("sticker saves once even if clicked twice", after == before + 1, f"{before}->{after}")
    check("save button shows Saved state", page.inner_text("#stkSave") == "Saved ✓")
    page.click("[data-stk-tab=text]"); page.click("[data-addtext=cute]")
    check("editing re-enables saving", page.inner_text("#stkSave") == "Save to timeline")
    with page.expect_download() as dl:
        page.click("#stkShare")
    check("share falls back to a PNG download", dl.value.suggested_filename.endswith(".png"), dl.value.suggested_filename)
    page.click("#stkReset")
    check("reset clears the layers", page.evaluate("Sticker._st.layers.length") == 0)
    page.click("#stkClose")
    page.click("[data-close=sheet-viewer]")
    stk_cards = page.evaluate("document.querySelectorAll('#timeline .moment.sticker').length")
    check("sticker appears on the timeline", stk_cards == 1, str(stk_cards))
    page.screenshot(path=f"{OUT}/s6_timeline_sticker.png")

    # journey overview + choose what to keep
    page.click(".tab[data-view=journey]")
    page.wait_for_selector(".jy-card")
    check("journey page shows years", page.locator(".jy-card[data-jy^='year:']").count() >= 1)
    page.click(".jy-card[data-jy^='year:'] >> nth=0")
    check("journey drills into months", page.locator(".jy-card[data-jy^='month:']").count() >= 1)
    page.click(".jy-card[data-jy^='month:'] >> nth=0")
    check("journey drills into days", page.locator(".jy-card[data-jy^='day:']").count() >= 1)
    page.screenshot(path=f"{OUT}/s6_journey.png")
    page.click(".jy-card[data-jy^='day:'] >> nth=0")
    check("a day opens on the timeline", page.evaluate("document.querySelector('#view-timeline').classList.contains('active')"))
    check("tidy card offers to review stacks", page.is_visible("#tidyCard"))
    page.click("#tidyCard"); page.wait_for_selector("#sheet-pick:not([hidden])")
    k0 = page.evaluate("state.photos.length")
    n_items = page.locator(".pick-item").count()
    page.screenshot(path=f"{OUT}/s6_pick.png")
    page.click("#pickGo"); page.wait_for_timeout(500)
    check("choose-what-to-keep deletes the unticked shots", page.evaluate("state.photos.length") == k0 - (n_items - 1), f"{k0}->{page.evaluate('state.photos.length')}")
    page.click("#pickClose")
    page.click(".tab[data-view=timeline]")

    # tidy
    ph_before = page.evaluate("state.photos.length")
    page.click(".moment.stack >> nth=0")
    cnt = page.evaluate("momentOf(viewer.photoId).items.length")
    page.click("[data-act=tidy]")
    page.wait_for_timeout(300)
    ph_after = page.evaluate("state.photos.length")
    check("'keep only the cover' deletes the others", ph_before - ph_after == cnt - 1, f"{ph_before}->{ph_after}, stack={cnt}")
    page.keyboard.press("Escape")

    page.click("#btnSettings")
    # clear demo
    page.click("#btnClearSample")
    page.wait_for_timeout(500)
    left = page.evaluate("state.photos.filter(p=>p.demo).length")
    check("sample photos can be removed", left == 0)

    # file import path: empty + wrong file type + good file
    page.click("[data-close=sheet-settings]")
    page.click(".tab[data-view=camera]")
    page.set_input_files("#fileInput", files=[{"name": "notes.txt", "mimeType": "text/plain", "buffer": b"hello"}])
    page.wait_for_timeout(300)
    check("non-image file is rejected with a message", "No images selected" in page.inner_text("#toast"), page.inner_text("#toast"))
    page.set_input_files("#fileInput", files=[{"name": "fake.jpg", "mimeType": "image/jpeg", "buffer": b"not really a jpeg"}])
    page.wait_for_timeout(600)
    check("corrupt image does not crash the app", "could not be read" in page.inner_text("#toast") or "Added" in page.inner_text("#toast"), page.inner_text("#toast"))

    # Escape / keyboard shutter
    n0 = page.evaluate("state.photos.length")
    page.evaluate("document.activeElement && document.activeElement.blur()")
    page.wait_for_function("document.querySelector('#video').videoWidth > 0", timeout=8000)
    page.keyboard.press("Space")
    page.wait_for_timeout(1800)
    n1 = page.evaluate("state.photos.length")
    check("space bar takes a photo on desktop", n1 > n0, f"{n0}->{n1}")
    page.close()

    # ---- permission denied path ----
    ctx2 = browser.new_context(viewport={"width": 390, "height": 820}, device_scale_factor=2, is_mobile=True, has_touch=True)
    ctx2.add_init_script("""
      navigator.mediaDevices.getUserMedia = () => Promise.reject(new DOMException('denied','NotAllowedError'));
    """)
    p2 = ctx2.new_page()
    p2.on("pageerror", lambda e: errors.append("PAGEERROR2 " + str(e)))
    p2.on("dialog", lambda d: d.accept())
    p2.goto(URL)
    p2.click("#obSkip")
    p2.wait_for_selector("#camMsg:not([hidden])")
    title = p2.inner_text("#camMsgTitle")
    check("denied permission shows a clear message", "denied" in title.lower(), title)
    p2.screenshot(path=f"{OUT}/s8_denied.png")
    p2.click("#btnShutter")
    check("shutter without camera gives feedback, not a crash", "not ready" in p2.inner_text("#toast").lower(), p2.inner_text("#toast"))
    p2.click("#btnDemo")
    p2.wait_for_function("document.querySelector('#view-timeline').classList.contains('active')", timeout=60000)
    check("sample photos work as the fallback", p2.evaluate("state.photos.length") > 20)
    p2.screenshot(path=f"{OUT}/s9_demo_fallback_timeline.png")
    # empty-tag state
    p2.click("#filterChips [data-filter=silly]")
    p2.click("#filterChips [data-filter=milestone]")
    # SW registered?
    sw = p2.evaluate("navigator.serviceWorker.getRegistrations().then(r => r.length)")
    check("service worker registers", sw >= 1, str(sw))
    manifest_ok = p2.evaluate("fetch('manifest.json').then(r=>r.ok)")
    check("manifest is served", manifest_ok is True)
    # language switch (English <-> 中文)
    p2.click(".topbar [data-lang-btn]")
    check("Chinese mode translates the tabs", "时间线" in p2.inner_text(".tabs, nav"), p2.inner_text(".tabs, nav").replace("\n", " "))
    p2.click(".tab[data-view=timeline]")
    check("Chinese mode translates generated text (stat line)", "张照片" in p2.inner_text("#statLine"), p2.inner_text("#statLine").replace("\n", " "))
    p2.click(".topbar [data-lang-btn]")
    check("switching back restores English", "Timeline" in p2.inner_text(".tabs, nav"))
    browser.close()

print("\nCONSOLE/PAGE ERRORS:", errors if errors else "none")
fails = [r for r in results if not r[1]]
print(f"\n{len(results)-len(fails)}/{len(results)} checks passed")
sys.exit(1 if fails else 0)
